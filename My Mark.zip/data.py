login = 'alexgrom1989'
password = 'alexusem1989'
game_name = 'Counter-Strike: Global Offensive'
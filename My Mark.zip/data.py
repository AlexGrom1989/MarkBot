login = ''
password = ''
game_name = 'Counter-Strike: Global Offensive'